#!/bin/bash

# Start Node.js app
cd /home/ec2-user/webapp
node server.js