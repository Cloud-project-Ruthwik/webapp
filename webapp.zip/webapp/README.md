
# webapp


networks and cloud computing assignments

Made using Node.js, Express.js   

To run, you need to install Node.js on your machine refer to this: https://nodejs.org/en/download/ 

for installation Move to the cloned repository and run "npm install" to install all packages mentioned in the dependencies section of package.json 

To run the server, use "node ./server.js" that runs the server.js file after cloning through preferably Visual Studio Code 

Server listens on port 3000 by default 

Use postman for testing API endpoints


APIs are built as per specifications here:  https://app.swaggerhub.com/apis-docs/csye6225-webapp/cloud-native-webapp/spring2023-a2
 
In order to make pull or merge requests the test cases in the workflow should pass. 


